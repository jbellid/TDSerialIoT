/*
  TinyGSM_1NCE_Plantilla.ino
  LilyGO T-SIM7080G-S3 (AXP2101) + SIM 1NCE
  Envia JSON UDP a 1NCE OS cuando hay datos pendientes.

  Bibliotecas: TinyGSM, XPowersLib (ademas de Arduino/Wire).
  TinyGSM gestiona registro y datos; SIM7080G AT gestiona UDP.
  Un solo propietario de SerialAT: llamadas TinyGSM y AT siempre secuenciales.
  No hay ACK del servidor: OK de CASEND NO garantiza entrega UDP.

  Conecta tu tarjeta mediante un cable USB-C de datos al ordenador. 
  En la pestaña Herramientas, cambia exactamente los siguientes parámetros para que coincidan con el hardware del T-SIM7080-S3:
      Placa (Board): ESP32S3 Dev Module
      USB CDC On Boot: Enabled (Crucial para ver el monitor serie)
      Flash Size:  16MB (128Mb)
      Partition Scheme:  16M Flash (3MB APP/9.9MB FATFS)
      PSRAM: OPI PSRAM
      Puerto (Port): Elige el puerto COM asignado a tu placa
*/

#define TINY_GSM_MODEM_SIM7080
#define XPOWERS_CHIP_AXP2101

#include <Arduino.h>
#include <Wire.h>
#include <XPowersLib.h>
#include <TinyGsmClient.h>

// ===== 1. PARAMETROS =====
constexpr int PIN_RX = 4, PIN_TX = 5, PIN_PWRKEY = 41, PIN_DTR = 42;
constexpr int PIN_SDA = 15, PIN_SCL = 7;
constexpr uint32_t BAUD_MODEM = 115200;

const char APN[]       = "iot.1nce.net";
const char HOST_UDP[]  = "udp.os.1nce.com";
constexpr uint16_t PUERTO_UDP = 4445;
const char DEVICE_ID[] = "tdsim7080-01";

constexpr uint32_t CADA_ENVIO_MS   = 60000;
constexpr uint32_t CADA_RED_MS     = 30000;
constexpr uint32_t REINTENTO_MS    = 10000;
constexpr bool DIAGNOSTICO_AT      = false; // true: CEREG / CNACT / CASTATE

// ===== ESTADO INTERNO =====
HardwareSerial SerialAT(1);
XPowersPMU PMU;
TinyGsm modem(SerialAT);

bool hardwareOK = false;
bool redOK = false;
bool udpOK = false;
bool udpSincronizado = false; // limpiar posible socket de un reinicio anterior
uint32_t ultimoDato = 0, ultimaRed = 0, ultimoIntento = 0;
uint32_t secuencia = 0;
bool hayPendiente = false;
String pendiente;

// Lee una respuesta AT hasta encontrar exito o ERROR, con limite temporal.
// Solo se llama cuando TinyGSM no esta usando SerialAT.
bool esperarAT(const char *exito, uint32_t timeoutMs) {
  String rx;
  rx.reserve(160);
  const uint32_t inicio = millis();
  while (millis() - inicio < timeoutMs) {
    while (SerialAT.available()) {
      rx += char(SerialAT.read());
      if (rx.indexOf(exito) >= 0) {
        if (DIAGNOSTICO_AT) Serial.println(rx);
        return true;
      }
      if (rx.indexOf("\r\nERROR\r\n") >= 0 ||
          rx.indexOf("+CME ERROR:") >= 0) {
        Serial.print("AT ERROR: "); Serial.println(rx);
        return false;
      }
      if (rx.length() > 240) rx.remove(0, 120);
    }
    delay(5);
  }
  Serial.print("AT timeout: "); Serial.println(rx);
  return false;
}

// ===== 2. HARDWARE Y RED =====
bool iniciarHardware() {
  if (!PMU.begin(Wire, AXP2101_SLAVE_ADDRESS, PIN_SDA, PIN_SCL)) return false;
  PMU.setDC3Voltage(3000);
  PMU.enableDC3();
  PMU.disableTSPinMeasure();

  SerialAT.begin(BAUD_MODEM, SERIAL_8N1, PIN_RX, PIN_TX);
  pinMode(PIN_PWRKEY, OUTPUT);
  pinMode(PIN_DTR, OUTPUT);
  digitalWrite(PIN_PWRKEY, LOW);
  digitalWrite(PIN_DTR, LOW);
  delay(1000);

  if (!modem.testAT(2000)) {
    digitalWrite(PIN_PWRKEY, HIGH);
    delay(1100);
    digitalWrite(PIN_PWRKEY, LOW);
  }
  for (int i = 0; i < 15; i++) {
    if (modem.testAT(1000)) return true;
    delay(1000);
  }
  return false;
}

bool conectarRed() {
  redOK = false;
  udpOK = false;
  udpSincronizado = false;
  Serial.println("Registrando red...");
  if (!modem.waitForNetwork(120000L)) return false;
  if (!modem.isGprsConnected() && !modem.gprsConnect(APN, "", "")) return false;
  redOK = modem.isGprsConnected();
  if (redOK) {
    Serial.print("Operador: "); Serial.println(modem.getOperator());
    Serial.print("IP: "); Serial.println(modem.localIP());
  }
  return redOK;
}

// ===== 3. UDP Y CARGA UTIL =====
void cerrarUDP(); // declaracion adelantada

bool abrirUDP() {
  if (udpOK) return true;
  if (!redOK) return false;

  // En el primer intento, el modem puede conservar un socket antiguo.
  if (!udpSincronizado) {
    cerrarUDP(); // ERROR al cerrar un socket inexistente es inocuo.
    udpSincronizado = true;
  }

  modem.sendAT("+CAOPEN=0,0,\"UDP\",\"", HOST_UDP, "\",", PUERTO_UDP);
  // El resultado asincrono +CAOPEN: 0,0 confirma que se abrio.
  udpOK = esperarAT("+CAOPEN: 0,0", 30000);
  if (!udpOK) {
    Serial.println("No se pudo abrir UDP");
    udpSincronizado = false; // forzar limpieza en el proximo intento
  }
  return udpOK;
}

void cerrarUDP() {
  modem.sendAT("+CACLOSE=0");
  // ERROR es admisible si ya estaba cerrado.
  esperarAT("\r\nOK\r\n", 3000);
  udpOK = false;
}

bool enviarPayload(const String &json) {
  if (!redOK || !abrirUDP()) return false;

  Serial.print("TX UDP: "); Serial.println(json);
  modem.sendAT("+CASEND=0,", json.length(), ",10000");
  if (!esperarAT(">", 10000)) return false;

  SerialAT.write(reinterpret_cast<const uint8_t *>(json.c_str()), json.length());
  if (!esperarAT("\r\nOK\r\n", 30000)) return false;

  Serial.println("Aceptado por el modem (sin ACK del servidor)");
  return true;
}

String crearPayload() {
  //***************************************************
  //            LA MADRE DEL CORDERO
  //
  // Sustituir por datos de sensores u otros sistemas.
  //
  //***************************************************
  String json = "{\"id\":\"";
  json += DEVICE_ID;
  json += "\",\"seq\":" + String(secuencia);
  json += ",\"uptime\":" + String(millis() / 1000);
  json += ",\"csq\":" + String(modem.getSignalQuality());
  json += "}";
  return json;
}

// ===== 4. POLLING DE LOS SISTEMAS =====
void pollingSistemas(uint32_t ahora) {
  // Ejemplo: generar un dato cada 60 s, solo si no hay otro pendiente.
  // Una cola de un mensaje no conserva nuevas medidas durante una caida.
  if (!hayPendiente && ahora - ultimoDato >= CADA_ENVIO_MS) {
    ultimoDato = ahora;
    ++secuencia;
    pendiente = crearPayload();
    hayPendiente = true;
  }
}

void diagnostico() {
  if (!DIAGNOSTICO_AT) return;
  modem.sendAT("+CEREG?");   esperarAT("\r\nOK\r\n", 3000);
  modem.sendAT("+CNACT?");   esperarAT("\r\nOK\r\n", 3000);
  modem.sendAT("+CASTATE?"); esperarAT("\r\nOK\r\n", 3000);
}

// ===== 5. SETUP =====
void setup() {
  Serial.begin(115200);
  delay(3000);
  Serial.println("=== TinyGSM + 1NCE / plantilla UDP ===");
  hardwareOK = iniciarHardware();
  if (!hardwareOK) {
    Serial.println("ERROR hardware/modem: revise alimentacion y cableado");
    return;
  }
  if (!modem.init()) Serial.println("Aviso: modem.init() fallo; se reintentara");
  // La conexion se intenta en loop, tambien si falla en el arranque.
}

// ===== 6. LOOP =====
void loop() {
  const uint32_t ahora = millis();

  // 1) Obtener datos de los sistemas conectados.
  pollingSistemas(ahora);

  if (!hardwareOK) { delay(1000); return; }

  // 2) Revisar red; reconectar solo si es necesario.
  if (!redOK || ahora - ultimaRed >= CADA_RED_MS) {
    ultimaRed = ahora;
    if (redOK) {
      redOK = modem.isNetworkConnected() && modem.isGprsConnected();
      if (!redOK) udpOK = false;
    }
    if (!redOK && ahora - ultimoIntento >= REINTENTO_MS) {
      ultimoIntento = ahora;
      if (!conectarRed()) Serial.println("Red no disponible; nuevo intento mas tarde");
    }
    diagnostico();
  }

  // 3) Enviar si hay algo pendiente; espaciar reintentos.
  if (hayPendiente && redOK && ahora - ultimoIntento >= REINTENTO_MS) {
    ultimoIntento = ahora;
    if (enviarPayload(pendiente)) {
      hayPendiente = false;
      pendiente = "";
    } else {
      Serial.println("Envio pendiente; se reintentara");
      // Se desconoce el estado del socket tras un error de envio.
      cerrarUDP();
    }
  }

  delay(50);
}
