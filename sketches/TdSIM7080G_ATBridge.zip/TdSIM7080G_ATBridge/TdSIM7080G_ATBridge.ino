/*
  Practica 01 - Puente AT USB <-> SIM7080G (v1.1)
  LilyGO T-SIM7080G-S3 (AXP2101)
  Biblioteca: XPowersLib

  Prueba AT al inicio;
  Una vez listo, puente serie completamente transparente.
*/
#include <Arduino.h>
#include <Wire.h>
#define XPOWERS_CHIP_AXP2101
#include <XPowersLib.h>

constexpr uint32_t BAUD = 115200;
constexpr int MODEM_RX = 4, MODEM_TX = 5, MODEM_PWR = 41;
constexpr int I2C_SDA = 15, I2C_SCL = 7;
XPowersPMU pmu;
HardwareSerial &modem = Serial1;

// Comprueba el modem sin depender de TinyGSM y muestra su respuesta.
bool probarAT(uint32_t timeoutMs = 1200) {
  while (modem.available()) modem.read();
  modem.print("AT\r");
  String respuesta;
  uint32_t inicio = millis();
  while (millis() - inicio < timeoutMs) {
    while (modem.available()) {
      char c = char(modem.read());
      respuesta += c;
      if (respuesta.indexOf("OK") >= 0) {
        Serial.println("[Inicio] Modem responde a AT: OK");
        return true;
      }
    }
    delay(1);
  }
  Serial.println("[Inicio] Sin respuesta a AT");
  return false;
}

void setup() {
  Serial.begin(BAUD);
  delay(500); 
  Serial.println("[Inicio] AT Bridge v1.1");

  if (!pmu.begin(Wire, AXP2101_SLAVE_ADDRESS, I2C_SDA, I2C_SCL)) {
    Serial.println("[ERROR] AXP2101 no detectado; revisar modelo de placa");
    while (true) delay(1000);
  }
  Serial.println("[Inicio] AXP2101 detectado");
  // BLDO1 alimenta el adaptador de niveles UART: imprescindible.
  pmu.setChargingLedMode(XPOWERS_CHG_LED_CTRL_CHG);
  pmu.setBLDO1Voltage(3300);
  pmu.enableBLDO1();
  pmu.setDC3Voltage(3000);
  pmu.enableDC3();
  delay(10000); //Damos tiempo de sobra para que se inicie el modem

  modem.begin(BAUD, SERIAL_8N1, MODEM_RX, MODEM_TX);
  pinMode(MODEM_PWR, OUTPUT);
  digitalWrite(MODEM_PWR, LOW);
  bool listo = false;
  for (int i = 0; i < 3 && !listo; i++) listo = probarAT();
  if (!listo) {
    delay(2500);
    for (int i = 0; i < 12 && !listo; i++) {
      listo = probarAT();
      if (!listo) delay(700);
    }
  }
  if (listo) {
    Serial.println("[OK] Puente transparente listo. Enviar AT seguido de CR.");
  } else {
    Serial.println("[ERROR] Modem sin respuesta. Revisar alimentacion y UART.");
    Serial.println("[INFO] Puente activo para diagnostico manual.");
  }
}

void loop() {
  while (Serial.available()) modem.write(Serial.read());
  while (modem.available()) Serial.write(modem.read());
  delay(1);
}
