# TdSIM7080_1NCE_UDP v0.6.1

Firmware sobre **v0.5.1 validada** en LilyGO T-SIM7080G-S3, firmware SIM7080G R1951.07.

## Novedades

- **Pulsador** (GPIO14 ↔ GND): al pulsar, **alterna** el estado del LED (GPIO10) y solicita un envío `event:"button"`. Antirrebote 45 ms; solo actúa en la transición a pulsado.
- **Sondeo de respaldo** `AT+CARECV=1,400` cada **60 segundos**, en vez de 5 s. Los avisos `+CADATAIND`, `+CANEW` y `buffer full` siguen provocando lectura inmediata. El sondeo es una salvaguarda ante URC perdidas, **no un requisito de UDP**. Puede variarse `DOWNLINK_POLL_MS` o desactivarse modificando la lógica del código, pero no se ha desactivado en esta versión.
- Comandos remotos adicionales `led_toggle`, `buzzer`, `gps`, `status`, `reboot`. Se conservan `led_on`, `led_off`, `telemetry`.
- Los comandos que implican operaciones de red prolongadas generan primero un ACK con `status:"accepted"` y después envían un JSON con el resultado (campo `cmd_id`). Los comandos inmediatos generan ACK `status:"executed"`.
- Se conservan los modos de terminal y la configuración del módem, DHT11, GNSS y batería. **No hay cambios para ahorro energético**.

## Configuración

1. Copiar el `utilities.h` oficial de LilyGO correspondiente a esta placa en la carpeta del `.ino`.
2. Instalar Arduino-ESP32 **3.x** y bibliotecas **XPowersLib**, **DHT sensor library** (Adafruit + Unified Sensor), **ArduinoJson 7.x**.
3. Sustituir `DOWNLINK_TOKEN` por el token ya utilizado en v0.5.1 (mínimo 16 caracteres). **Nunca subir credenciales reales a un repositorio público**.
4. El puerto de downlink sigue siendo **3000**; uplink **udp.os.1nce.com:4445**, APN `iot.1nce.net`.
5. DHT11 desconectado: campos de temperatura y humedad `null`, comportamiento previsto.

## Órdenes para Device Controller (UDP, puerto 3000)

Agregar siempre `"token":"TU_TOKEN_REAL"` y un `id` entero **nuevo** (los ocho últimos se guardan en RAM para evitar duplicados).

```json
{"cmd":"led_on","id":201,"token":"TU_TOKEN_REAL"}
{"cmd":"led_off","id":202,"token":"TU_TOKEN_REAL"}
{"cmd":"led_toggle","id":203,"token":"TU_TOKEN_REAL"}
{"cmd":"buzzer","id":204,"duration_ms":350,"token":"TU_TOKEN_REAL"}
{"cmd":"telemetry","id":205,"token":"TU_TOKEN_REAL"}
{"cmd":"status","id":206,"token":"TU_TOKEN_REAL"}
{"cmd":"gps","id":207,"token":"TU_TOKEN_REAL"}
{"cmd":"reboot","id":208,"confirm":"REBOOT","token":"TU_TOKEN_REAL"}
```

`buzzer`: duración permitida de **50 a 2000 ms**, tono 1800 Hz; usar buzzer piezo pasivo apto para 3,3 V. `reboot` requiere `confirm: "REBOOT"`; solo usar en laboratorio. Token simple sin autenticación criptográfica ni protección persistente contra repetición: **no es un mecanismo seguro para actuadores críticos**.

## Respuestas y semántica

- `led_on`, `led_off`, `led_toggle`, `buzzer`: ACK `event:"command_ack"`, `status:"executed"` tras ejecutar.
- `telemetry`, `status`, `gps`: ACK `status:"accepted"`; después otro paquete con `event:"remote"`, `"status"` o `"gps"` y `cmd_id` para correlación. No equivale a un OK de ejecución: confirmar el mensaje de resultado en Historian.
- `gps`: detiene temporalmente LTE, obtiene (o intenta) posición, recupera LTE y vuelve a abrir el receptor en el siguiente ciclo. La posición se distingue por `gps_valid`, `gps_cached` y `gps_age_s`.
- `reboot`: ACK `status:"accepted"`, y después `ESP.restart()`. El ACK puede no llegar; el reinicio no incluye ACK posterior. Si se desea confirmar el reinicio, añadir un evento `boot` en versiones posteriores.
- `AT+CASEND ... OK` indica **aceptación por el módem**, no entrega garantizada; verificar Historian.
- Si llega una segunda orden larga mientras otra está pendiente, se rechaza para evitar sobrescribirla.

## Comandos serie

`!` conmuta puente AT / automático, `d` trazas, `s` enviar, `l` alternar LED y enviar, `g` GPS y enviar, `p` vista previa, `n` radio, `c` contadores, `r` receptor.

## Pruebas sugeridas

Primero `led_toggle` (comprueba alternancia física y ACK), luego `buzzer`, `status`, `telemetry`, finalmente `gps`. Comprobar que llega cada respuesta a Historian. `reboot` solamente cuando se confirme que el estado del módem vuelve a ser correcto tras reiniciar.

## Limitaciones

Compilación y ejecución **no verificadas en hardware** aquí. La recepción es dependiente de URC, con sondeo de respaldo cada 60 s. Si una URC se pierde, la reacción puede demorarse hasta 60 s. Durante GNSS no se pueden recibir órdenes LTE. La operación de GPS sigue bloqueando el bucle durante su adquisición/recuperación (hasta los límites configurados); el sondeo no trabaja en ese intervalo. Los comandos remotos autorizan acciones mediante token en texto claro en un datagrama UDP; no usar para funciones de seguridad física ni desplegar en entornos no controlados.
