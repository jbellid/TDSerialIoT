/*
 * TdSIM7080_1NCE_UDP v0.6.2 (telemetria UDP + Device Controller UDP bidireccional)
 * Basado en la secuencia de arranque de ATDebug.ino de LilyGO (MIT, Lewis He).
 * Hardware: LilyGO T-SIM7080G-S3 + AXP2101, SIN camara ni tarjeta microSD.
 * Transporte: UDP nativo SIM7080G -> udp.os.1nce.com:4445
 *
 * IMPORTANTE: GNSS y radio celular del SIM7080G son mutuamente excluyentes:
 *            GNSS se activa temporalmente y DESPUES se reactiva LTE.
 *            Durante GNSS no llegan datos por LTE.
 * USB: '!' cambia entre comandos AT directos y control automatico.
 *      's' solicita envio; 'l' alterna LED y envia; 'g' fuerza nueva lectura GNSS;
 *      'p' muestra lectura/estado red; 'n' diagnostico de red; 'd' trazas AT;
 *      'c' muestra contadores UDP; 'r' fuerza reapertura del receptor.
 * v0.6.2: recuperacion de servidor UDP tras GNSS y sockets residuales.
 * Conserva comandos ampliados, pulsador alterna LED y sondeo respaldo 60 s.
 * Requiere ArduinoJson 7.x. Personalizar DOWNLINK_TOKEN antes de usar.
 * Estado UDP: 'OK' confirma aceptacion local, NO recepcion por 1NCE.
 */
#include <Arduino.h>
#include <Wire.h>
#include <DHT.h>
#include <ArduinoJson.h>
#include "utilities.h"  // Copiar el archivo utilities.h original de LilyGO a esta carpeta
#define XPOWERS_CHIP_AXP2101
#include <XPowersLib.h>

#define SerialAT Serial1

// GPIO disponibles solo si NO se usan los perifericos opcionales indicados.
constexpr uint8_t PIN_DHT = 9;      // Compartido con camara VSYNC
constexpr uint8_t PIN_LED = 10;     // Compartido con microSD CS
constexpr uint8_t PIN_BUTTON = 14;  // Compartido con camara HREF
constexpr uint8_t PIN_BUZZER = 21;  // Compartido con camara XCLK

constexpr uint32_t EVERY_MS = 3600000UL;
constexpr uint32_t RETRY_MS = 60000UL;
constexpr uint32_t DEBOUNCE_MS = 45UL;
constexpr uint32_t GNSS_MAX_MS = 90000UL;  // Primera posicion puede tardar mas
// GPS separado de la telemetria: g lo fuerza. Habilitar periodo si procede.
constexpr bool GPS_AUTOMATICO = false;  // No interrumpir LTE en pruebas interiores
constexpr uint32_t GPS_INTERVAL_MS = 6UL * 3600000UL;
constexpr uint32_t RADIO_RECOVERY_TIMEOUT_MS = 120000UL;
constexpr uint8_t RADIO_METRICS_RETRIES = 4;
constexpr uint32_t RADIO_METRICS_RETRY_MS = 2000UL;
constexpr bool AT_DEBUG_INICIAL = false; // tecla d conmuta trazas sin reiniciar

const char APN[] = "iot.1nce.net";
const char UDP_HOST[] = "udp.os.1nce.com";
constexpr uint16_t UDP_PORT = 4445;
constexpr uint16_t DOWNLINK_PORT = 3000;
constexpr uint8_t UPLINK_SOCKET = 0;
constexpr uint8_t DOWNLINK_SOCKET = 1;
// Clave de aplicacion, distinta de la SIM. No publicar un firmware con clave real.
// Cambiar por una cadena aleatoria larga; el mismo valor debe viajar en cada orden.
const char DOWNLINK_TOKEN[] = "CAMBIAR_CLAVE_ANTES_DE_USAR";
constexpr uint32_t DOWNLINK_RECHECK_MS = 180000UL;
constexpr uint32_t DOWNLINK_POLL_MS = 60000UL; // respaldo si se pierde URC: 60 s
constexpr uint8_t DOWNLINK_MAX_DRAIN = 4;   // no monopolizar el modem
constexpr uint32_t DOWNLINK_RETRY_MS = 15000UL;
const char DEVICE_ID[] = "tdsim7080-01";

XPowersPMU PMU;
DHT dht(PIN_DHT, DHT11);
bool ledOn = false, manualAT = false, atDebug = AT_DEBUG_INICIAL;
bool pendingSend = false, forceGPS = false, pendingRetry = false;
const char *pendingReason = "manual";
uint32_t lastSendAttempt = 0, lastButtonEdge = 0, lastGPSAttempt = 0;
uint32_t packetSeq = 0; // se reinicia al reiniciar ESP32; incluye reintentos
uint32_t downlinkAccepted = 0, downlinkRejected = 0, downlinkAcks = 0;
// Acciones largas se ejecutan fuera de la recepcion CARECV/gestion del ACK.
enum DeferredAction : uint8_t { ACTION_NONE, ACTION_TELEMETRY, ACTION_GPS, ACTION_STATUS, ACTION_REBOOT };
DeferredAction deferredAction = ACTION_NONE;
uint32_t deferredCmdId = 0;
int32_t telemetryCmdId = -1; // correlacion de respuesta para acciones remotas
int recentCmdIds[8] = {-1,-1,-1,-1,-1,-1,-1,-1};
uint8_t cmdIdCursor = 0;
bool downlinkReady = false;
int rxPendingId = -1;
uint32_t lastDownlinkCheck = 0;
uint32_t lastDownlinkAttempt = 0;
uint32_t lastDownlinkPoll = 0;
uint32_t rxURCCount = 0, rxPollCount = 0, rxEmptyCount = 0, rxReadErrors = 0;
String unsolicitedLine;
uint32_t udpAccepted = 0, udpFailed = 0; // aceptacion LOCAL, no entrega confirmada
bool lastButtonRaw = HIGH, buttonStable = HIGH;
float lastTemp = NAN, lastHumidity = NAN;
double lastLat = 0, lastLon = 0;
bool lastGPSFix = false;
uint32_t lastGPSFixMs = 0; // marca temporal monotona de la ultima posicion valida

// Detecta avisos del modem incluso si se intercalan con las respuestas AT.
void inspectURCs(const String &buffer) {
  int start = 0;
  while (start < (int)buffer.length()) {
    int end = buffer.indexOf('\n', start);
    if (end < 0) end = buffer.length();
    String line = buffer.substring(start, end); line.trim();
    if (line.startsWith("+CADATAIND:")) {
      int cid = line.substring(strlen("+CADATAIND:")).toInt();
      if (cid == DOWNLINK_SOCKET) { rxPendingId = cid; ++rxURCCount; }
    } else if (line.startsWith("+CANEW:")) {
      // Puede llegar con CADATAIND; comprobacion en el siguiente loop.
      if (line.startsWith(String("+CANEW: ") + DOWNLINK_SOCKET + ",")) rxPendingId = DOWNLINK_SOCKET;
    } else if (line.startsWith("+CAURC:") && line.indexOf("buffer full") >= 0) {
      rxPendingId = DOWNLINK_SOCKET;
      Serial.println("DOWNLINK: aviso de buffer lleno; solicitando lectura");
    } else if (line.startsWith("+APP PDP:") && line.indexOf("DEACTIVE") >= 0) {
      downlinkReady = false;
    }
    start = end + 1;
  }
}

// Declaracion adelantada: getGPS() espera red tras restaurar LTE.
bool waitNetwork(uint32_t timeoutMs);
void readSignal();
void readRadio();
bool sendTelemetry(const char *reason);
bool suspendDownlinkForGNSS();
bool ensureDownlink(bool forceCheck);

void beep() {
  ledcWriteTone(PIN_BUZZER, 1800);
  delay(120);
  ledcWriteTone(PIN_BUZZER, 0);
}

// Captura respuesta AT, incluidos URC entre OK y +CAOPEN.
// Logging opcional para evitar inundar el terminal en modo normal.
void traceTX(const String &s) {
  if (atDebug) { Serial.print("[AT TX] "); Serial.println(s); }
}
void traceRX(const String &s) {
  if (atDebug && s.length()) {
    // CARECV puede incluir credenciales de aplicacion: nunca imprimir el token.
    String safe = s;
    if (strlen(DOWNLINK_TOKEN) && strcmp(DOWNLINK_TOKEN, "CAMBIAR_CLAVE_ANTES_DE_USAR") != 0)
      safe.replace(DOWNLINK_TOKEN, "[TOKEN_OCULTO]");
    int t = safe.indexOf("\"token\":");
    if (t >= 0) {
      int q1 = safe.indexOf('"', t + 8);
      int q2 = q1 < 0 ? -1 : safe.indexOf('"', q1 + 1);
      if (q1 >= 0 && q2 > q1) safe = safe.substring(0, q1 + 1) + "***" + safe.substring(q2);
    }
    Serial.print("[AT RX] "); Serial.println(safe);
  }
}

bool waitAT(const String &token, uint32_t timeoutMs, String *out = nullptr) {
  String received;
  uint32_t beginMs = millis();
  while (millis() - beginMs < timeoutMs) {
    while (SerialAT.available()) {
      char c = (char)SerialAT.read();
      received += c;
      if (received.length() > 2200) received.remove(0, 600);
      if (received.indexOf(token) >= 0) {
        if (out) *out = received;
        inspectURCs(received);
        traceRX(received);
        return true;
      }
      if (received.indexOf("\r\nERROR\r\n") >= 0 ||
          received.indexOf("+CME ERROR:") >= 0 ||
          received.indexOf("+CMS ERROR:") >= 0) {
        if (out) *out = received;
        inspectURCs(received);
        traceRX(received);
        return false;
      }
    }
    delay(2);
  }
  if (out) *out = received;
  inspectURCs(received);
  traceRX(received);
  return false;
}

void flushAT() {
  // Residuales (URC) solo para diagnostico; nunca durante operacion critica.
  String discarded;
  while (SerialAT.available()) {
    discarded += (char)SerialAT.read();
    if (discarded.length() > 512) discarded.remove(0, 128);
  }
  if (discarded.length()) { inspectURCs(discarded); traceRX(String("[residual] ") + discarded); }
}

bool command(const String &s, uint32_t timeoutMs = 4000,
             String *out = nullptr, bool quietFailure = false) {
  flushAT();
  traceTX(s);
  SerialAT.print(s); SerialAT.print("\r\n");
  String answer;
  bool ok = waitAT("\r\nOK\r\n", timeoutMs, &answer);
  if (out) *out = answer;
  if (!ok && !quietFailure) {
    Serial.print("AT fallo: "); Serial.println(s); Serial.println(answer);
  }
  return ok;
}

bool getGPS() {
  // La documentacion LilyGO indica que hay que apagar LTE para fijar GNSS.
  // v0.6.2: liberar el servidor mientras LTE sigue disponible.
  // El firmware R1951B17 mantiene CASERVER tras CFUN=0 pero cambia CASTATE a 1,0.
  // Si no logramos liberar, no interrumpimos LTE: se puede reintentar GNSS.
  if (!suspendDownlinkForGNSS()) {
    Serial.println("GNSS: abortado; servidor UDP no se pudo liberar con seguridad");
    return false;
  }
  lastGPSAttempt = millis();
  const uint32_t gpsStartedMs = millis();
  Serial.println("GNSS: pausando radio LTE (puede tardar 90 s)...");
  if (!command("AT+CFUN=0", 12000)) {
    Serial.println("GNSS: no se pudo desactivar LTE; no se inicia GNSS");
    return false;
  }
  bool gotFix = false;
  if (command("AT+SGPIO=0,5,1,1") && command("AT+CGNSPWR=1", 12000)) {
    uint32_t beginMs = millis();
    while (millis() - beginMs < GNSS_MAX_MS) {
      String response;
      if (command("AT+CGNSINF", 4500, &response)) {
        int p = response.indexOf("+CGNSINF:");
        if (p >= 0) {
          int eol = response.indexOf('\n', p);
          String row = response.substring(p + 9, eol < 0 ? response.length() : eol);
          row.trim();
          String fields[5];
          int start = 0;
          bool valid = true;
          for (int i = 0; i < 5; i++) {
            int comma = row.indexOf(',', start);
            if (comma < 0 && i < 4) { valid = false; break; }
            fields[i] = row.substring(start, comma < 0 ? row.length() : comma);
            fields[i].trim();
            start = comma + 1;
          }
          if (valid && fields[1] == "1" && fields[3].length() && fields[4].length()) {
            lastLat = fields[3].toDouble();
            lastLon = fields[4].toDouble();
            gotFix = true;
            lastGPSFix = true;
            lastGPSFixMs = millis();
            Serial.printf("GNSS: lat %.6f lon %.6f (fix tras %lu s)\n",
                          lastLat, lastLon,
                          (unsigned long)((millis() - gpsStartedMs) / 1000UL));
            break;
          }
        }
      }
      delay(1500);
    }
  }
  command("AT+CGNSPWR=0", 12000);
  command("AT+SGPIO=0,5,1,0");
  // Restaurar LTE independientemente de si hubo fix.
  const uint32_t restoreStartedMs = millis();
  Serial.println("LTE: restaurando radio tras GNSS...");
  bool radioRestored = command("AT+CFUN=1", 18000);
  if (!radioRestored) {
    Serial.println("AVISO: AT+CFUN=1 fallo; comprobar el modem en modo AT");
  } else {
    Serial.println("LTE: esperando registro CEREG=1/5 tras GNSS...");
    if (waitNetwork(RADIO_RECOVERY_TIMEOUT_MS)) {
      Serial.printf("LTE: registrado tras %lu s desde CFUN=1\n",
                    (unsigned long)((millis() - restoreStartedMs) / 1000UL));
    } else {
      Serial.println("AVISO: LTE aun sin registro; las metricas pueden ser desconocidas");
    }
  }
  if (!gotFix) Serial.println("GNSS: sin fix nuevo; se conserva el ultimo si existia");
  // Reabrir receptor al recuperar radio y PDP, tambien para GNSS automatico.
  // No confundir CEREG=5 con PDP de aplicacion activo: ensureDownlink comprueba ambos.
  lastDownlinkAttempt = 0;
  if (radioRestored && ensureDownlink(true)) {
    Serial.println("DOWNLINK: receptor UDP restaurado despues de GNSS");
  } else {
    Serial.println("AVISO: receptor UDP pendiente de recuperacion tras GNSS; reintento en loop");
  }
  return gotFix;
}

bool registered() {
  String response;
  if (!command("AT+CEREG?", 3500, &response)) return false;
  int p = response.indexOf("+CEREG:");
  if (p < 0) return false;
  int comma = response.indexOf(',', p);
  if (comma < 0) return false;
  int status = response.substring(comma + 1).toInt();
  return status == 1 || status == 5;  // local o roaming
}

bool waitNetwork(uint32_t timeoutMs = 120000UL) {
  uint32_t started = millis();
  while (millis() - started < timeoutMs) {
    if (registered()) return true;
    delay(2000);
  }
  Serial.println("LTE: sin registro CEREG=1/5");
  return false;
}

bool ensureAppPDP() {
  // +CNACT es el contexto de APLICACION usado por los sockets CAOPEN.
  // No debe confundirse con el CID de AT+CGACT? del diagnostico de TDSerialIoT.
  String r;
  if (command("AT+CNACT?", 3500, &r) && r.indexOf("+CNACT: 0,1,") >= 0) return true;
  if (!command(String("AT+CNCFG=0,1,\"") + APN + "\"")) return false;
  command("AT+CNACT=0,1", 10000);  // puede notificar +APP PDP: 0,ACTIVE de forma asincrona
  for (int i = 0; i < 12; i++) {
    delay(1500);
    if (command("AT+CNACT?", 3500, &r) && r.indexOf("+CNACT: 0,1,") >= 0) return true;
  }
  Serial.println("PDP aplicacion 0 no activo (AT+CNACT?)");
  return false;
}

String atValue(const String &response, const char *prefix);

bool sendUDP(const String &json) {
  if (json.length() > 508) {
    Serial.println("UDP: JSON supera 508 bytes; envio cancelado");
    return false;
  }
  Serial.printf("UDP: iniciando (%u bytes) -> %s:%u\n",
                (unsigned)json.length(), UDP_HOST, UDP_PORT);
  if (!waitNetwork()) return false;
  if (!ensureAppPDP()) return false;

  // Cerramos socket 0 SOLO si CAState indica que esta activo.
  // AT+CASTATE?: +CASTATE: <cid>,<state>, 1=conectado, 2=escucha, 0=cerrado.
  // Si la consulta falla, no cerramos a ciegas: CAOPEN dara error diagnosticable.
  String socketState;
  if (command("AT+CASTATE?", 3500, &socketState, true)) {
    String state = atValue(socketState, "+CASTATE: 0,");
    if (state.startsWith("1") || state.startsWith("2")) {
      Serial.println("UDP: socket 0 previo activo, cerrando antes de abrir");
      if (!command("AT+CACLOSE=0", 4000, nullptr, true)) {
        Serial.println("UDP: no se pudo cerrar socket previo");
        return false;
      }
    }
  }

  const String openCmd = String("AT+CAOPEN=0,0,\"UDP\",\"") + UDP_HOST +
                         "\"," + String(UDP_PORT);
  flushAT();
  traceTX(openCmd);
  SerialAT.print(openCmd); SerialAT.print("\r\n");
  String openReply;
  // URC de apertura: +CAOPEN: 0,0; puede ir seguido de OK.
  if (!waitAT("+CAOPEN: 0,0", 30000, &openReply)) {
    Serial.println("UDP: CAOPEN sin confirmacion de apertura: " + openReply);
    return false;
  }
  Serial.println("UDP: socket 0 abierto");

  flushAT();
  const String sendCmd = String("AT+CASEND=0,") + json.length();
  traceTX(sendCmd);
  SerialAT.print(sendCmd); SerialAT.print("\r\n");
  String promptReply;
  if (!waitAT(">", 6000, &promptReply)) {
    Serial.println("UDP: CASEND sin prompt: " + promptReply);
    command("AT+CACLOSE=0", 4000, nullptr, true);
    return false;
  }
  // Algunas revisiones imprimen +CASEND: <cid>,<datalen> ANTES del prompt.
  traceTX(String("<JSON ") + json.length() + " bytes>");
  SerialAT.write((const uint8_t *)json.c_str(), json.length());
  String sendReply;
  bool accepted = waitAT("\r\nOK\r\n", 15000, &sendReply);
  if (!accepted) {
    Serial.println("UDP: CASEND no aceptado: " + sendReply);
  } else {
    Serial.println("UDP: CASEND OK (aceptacion local; verificar 1NCE OS)");
  }
  // Cierre de nuestro socket conocido; fallo silencioso salvo traza.
  command("AT+CACLOSE=0", 5000, nullptr, true);
  return accepted;
}


// Servidor UDP para ordenes de 1NCE OS Device Controller.
// SIMCom documenta AT+CASERVER=<cid>,<pdp>,"UDP",<local_port>.
// La telemetria sigue usando un socket distinto (CID 0).
// Interpretacion empiricamente validada en SIM7080G R1951B17:
// CASTATE 1,2 = escuchando; CASTATE 1,0 = cerrado, PERO CASERVER aun puede
// conservar el registro del puerto. CACLOSE=1 elimina tanto estado como servidor.
int socketStatus(uint8_t cid, const String &state) {
  String needle = "+CASTATE: " + String(cid) + ",";
  int p = state.indexOf(needle);
  if (p < 0) return -1; // sin entrada para este CID
  return state.substring(p + needle.length()).toInt();
}

bool socketIsActive(uint8_t cid, const String &state) {
  int st = socketStatus(cid, state);
  return st == 1 || st == 2;
}

bool serverConfigured(uint8_t cid, const String &reply) {
  return reply.indexOf(String("+CASERVER: ") + cid + ",") >= 0;
}

// Suspende solo el servidor de downlink (CID 1), NO el contexto PDP ni el
// socket de subida (CID 0). El cierre se realiza ANTES de CFUN=0.
bool suspendDownlinkForGNSS() {
  if (manualAT) return false;
  String state, server;
  if (!command("AT+CASTATE?", 4000, &state, true) ||
      !command("AT+CASERVER?", 4000, &server, true)) {
    Serial.println("DOWNLINK: imposible consultar estado antes de GNSS");
    return false;
  }
  int status = socketStatus(DOWNLINK_SOCKET, state);
  bool configured = serverConfigured(DOWNLINK_SOCKET, server);
  if (status >= 0 || configured) {
    Serial.printf("DOWNLINK: cerrando CID %u antes de GNSS (estado=%d, servidor=%s)\n",
                  DOWNLINK_SOCKET, status, configured ? "si" : "no");
    if (!command(String("AT+CACLOSE=") + DOWNLINK_SOCKET, 6000, nullptr, true)) {
      Serial.println("DOWNLINK: fallo CACLOSE antes de GNSS");
      return false;
    }
    // Verificar que la configuracion y el socket han desaparecido.
    if (!command("AT+CASTATE?", 4000, &state, true) ||
        !command("AT+CASERVER?", 4000, &server, true) ||
        socketStatus(DOWNLINK_SOCKET, state) >= 0 ||
        serverConfigured(DOWNLINK_SOCKET, server)) {
      Serial.println("DOWNLINK: CID 1 no liberado tras CACLOSE");
      return false;
    }
  }
  downlinkReady = false;
  rxPendingId = -1;
  lastDownlinkAttempt = 0;
  Serial.println("DOWNLINK: receptor suspendido correctamente para GNSS");
  return true;
}

bool ensureDownlink(bool forceCheck = false) {
  if (manualAT) return false;
  uint32_t now = millis();
  if (downlinkReady && !forceCheck && (now - lastDownlinkCheck < DOWNLINK_RECHECK_MS)) return true;
  if (!forceCheck && !downlinkReady && lastDownlinkAttempt &&
      (now - lastDownlinkAttempt < DOWNLINK_RETRY_MS)) return false;
  lastDownlinkAttempt = now;

  String state, server;
  if (!command("AT+CASTATE?", 4000, &state, true)) {
    downlinkReady = false;
    Serial.println("DOWNLINK: no se pudo consultar CASTATE");
    return false;
  }
  int st = socketStatus(DOWNLINK_SOCKET, state);
  if (st == 2) {
    // Verificar que no es un socket de otra clase sobre el mismo CID.
    if (!command("AT+CASERVER?", 4000, &server, true)) {
      downlinkReady = false;
      return false;
    }
    if (serverConfigured(DOWNLINK_SOCKET, server) &&
        server.indexOf(String("+CASERVER: ") + DOWNLINK_SOCKET + ",0,\"UDP\"," + DOWNLINK_PORT) >= 0) {
      if (!downlinkReady) rxPendingId = DOWNLINK_SOCKET;
      downlinkReady = true;
      lastDownlinkCheck = millis();
      return true;
    }
    Serial.println("DOWNLINK: CID 1 en escucha con configuracion inesperada; no se sobrescribe");
    downlinkReady = false;
    return false;
  }
  downlinkReady = false;
  if (!registered() || !ensureAppPDP()) return false;

  if (!command("AT+CASERVER?", 4000, &server, true)) {
    Serial.println("DOWNLINK: no se pudo consultar CASERVER");
    return false;
  }
  const bool configured = serverConfigured(DOWNLINK_SOCKET, server);
  // CASERVER retiene puerto cuando CASTATE=1,0 tras volver de GNSS.
  // Primero liberamos con CACLOSE=1, secuencia validada en la placa real.
  if (st >= 0 || configured) {
    Serial.printf("DOWNLINK: CID %u residual (estado=%d, servidor=%s); liberando\n",
                  DOWNLINK_SOCKET, st, configured ? "si" : "no");
    if (!command(String("AT+CACLOSE=") + DOWNLINK_SOCKET, 6000, nullptr, true)) {
      Serial.println("DOWNLINK: CACLOSE=1 fallo; reintento posterior");
      return false;
    }
    if (!command("AT+CASTATE?", 4000, &state, true) ||
        !command("AT+CASERVER?", 4000, &server, true) ||
        socketStatus(DOWNLINK_SOCKET, state) >= 0 ||
        serverConfigured(DOWNLINK_SOCKET, server)) {
      Serial.println("DOWNLINK: CID 1 continua reservado tras CACLOSE; reintento posterior");
      return false;
    }
  }

  const String cmd = String("AT+CASERVER=") + DOWNLINK_SOCKET + ",0,\"UDP\"," + DOWNLINK_PORT;
  flushAT(); traceTX(cmd);
  SerialAT.print(cmd); SerialAT.print("\r\n");
  String reply;
  // El firmware probado devuelve +CASERVER: 1,0 seguido de OK.
  const String expected = String("+CASERVER: ") + DOWNLINK_SOCKET + ",0";
  if (!waitAT(expected, 12000, &reply)) {
    Serial.println("DOWNLINK: no se pudo abrir UDP 3000: " + reply);
    return false;
  }
  // Confirmar que realmente escucha, no solamente que se acepto CASERVER.
  if (!command("AT+CASTATE?", 4000, &state, true) ||
      socketStatus(DOWNLINK_SOCKET, state) != 2) {
    Serial.println("DOWNLINK: CASERVER aceptado, pero CID 1 no esta escuchando");
    return false;
  }
  downlinkReady = true;
  lastDownlinkCheck = millis();
  rxPendingId = DOWNLINK_SOCKET;
  lastDownlinkPoll = 0;
  Serial.println("DOWNLINK: servidor UDP escuchando en puerto 3000 (CID 1)");
  return true;
}

// Recoge URC que llegan sin un comando AT en ejecucion.
void collectIdleURCs() {
  while (SerialAT.available()) {
    char ch = (char)SerialAT.read();
    unsolicitedLine += ch;
    if (ch == '\n') {
      inspectURCs(unsolicitedLine);
      traceRX(unsolicitedLine);
      unsolicitedLine = "";
    }
    if (unsolicitedLine.length() > 700) unsolicitedLine = "";
  }
}

// No ejecutar operaciones AT largas dentro de la lectura CARECV.
// Se envia ACK de "accepted" para acciones diferidas y un evento posterior
// (telemetria/status/gps) al completar la operacion. "executed" = ya realizada.
// El ID solo evita duplicados de los ocho ultimos comandos (en RAM).
void handleDownlink(const String &data) {
  if (data.length() > 400) { Serial.println("DOWNLINK: longitud excesiva"); ++downlinkRejected; return; }
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, data);
  if (err || !doc.is<JsonObject>()) {
    Serial.println("DOWNLINK: JSON invalido"); ++downlinkRejected; return;
  }
  const char *token = doc["token"] | "";
  const char *cmd = doc["cmd"] | "";
  int id = doc["id"] | -1;
  if (strlen(DOWNLINK_TOKEN) < 16 || strcmp(DOWNLINK_TOKEN, "CAMBIAR_CLAVE_ANTES_DE_USAR") == 0 ||
      strcmp(token, DOWNLINK_TOKEN) != 0 || id < 0) {
    Serial.println("DOWNLINK: autenticacion/ID incorrectos. Orden ignorada.");
    ++downlinkRejected; return;
  }
  for (int seen : recentCmdIds) {
    if (seen == id) {
      Serial.printf("DOWNLINK: id repetido %d, no se vuelve a ejecutar\n", id);
      ++downlinkRejected; return;
    }
  }

  bool deferred = false;
  if (strcmp(cmd, "led_on") == 0) {
    ledOn = true; digitalWrite(PIN_LED, HIGH);
  } else if (strcmp(cmd, "led_off") == 0) {
    ledOn = false; digitalWrite(PIN_LED, LOW);
  } else if (strcmp(cmd, "led_toggle") == 0) {
    ledOn = !ledOn; digitalWrite(PIN_LED, ledOn ? HIGH : LOW);
  } else if (strcmp(cmd, "buzzer") == 0) {
    // Un piezo pasivo de baja corriente conectado como en el esquema.
    // Limite para impedir tonos excesivamente largos por una orden erronea.
    int duration = doc["duration_ms"] | 300;
    if (duration < 50 || duration > 2000) {
      Serial.println("DOWNLINK: duration_ms fuera de rango (50..2000)");
      ++downlinkRejected; return;
    }
    ledcWriteTone(PIN_BUZZER, 1800);
    delay((uint32_t)duration);
    ledcWriteTone(PIN_BUZZER, 0);
  } else if (strcmp(cmd, "telemetry") == 0 ||
             strcmp(cmd, "gps") == 0 ||
             strcmp(cmd, "status") == 0 ||
             strcmp(cmd, "reboot") == 0) {
    if (deferredAction != ACTION_NONE || pendingSend) {
      Serial.println("DOWNLINK: ocupado con otra accion/envio, orden rechazada");
      ++downlinkRejected; return;
    }
    if (strcmp(cmd, "reboot") == 0) {
      const char *confirmation = doc["confirm"] | "";
      if (strcmp(confirmation, "REBOOT") != 0) {
        Serial.println("DOWNLINK: reboot requiere confirm=REBOOT");
        ++downlinkRejected; return;
      }
      deferredAction = ACTION_REBOOT;
    } else if (strcmp(cmd, "telemetry") == 0) deferredAction = ACTION_TELEMETRY;
    else if (strcmp(cmd, "gps") == 0) deferredAction = ACTION_GPS;
    else deferredAction = ACTION_STATUS;
    deferredCmdId = (uint32_t)id;
    deferred = true;
  } else {
    Serial.println("DOWNLINK: comando desconocido"); ++downlinkRejected; return;
  }

  recentCmdIds[cmdIdCursor] = id;
  cmdIdCursor = (cmdIdCursor + 1) % 8;
  ++downlinkAccepted;
  Serial.printf("DOWNLINK: %s %s (id=%d)\n", deferred ? "aceptado" : "ejecutado", cmd, id);
  // Para tareas diferidas, "accepted" no significa que hayan finalizado.
  JsonDocument ackDoc;
  ackDoc["id"] = DEVICE_ID;
  ackDoc["event"] = "command_ack";
  ackDoc["cmd_id"] = id;
  ackDoc["status"] = deferred ? "accepted" : "executed";
  ackDoc["cmd"] = cmd;
  ackDoc["led"] = ledOn;
  String ack;
  serializeJson(ackDoc, ack);
  if (sendUDP(ack)) { ++downlinkAcks; Serial.println("DOWNLINK: ACK aceptado por modem"); }
  else Serial.println("DOWNLINK: no se pudo enviar ACK (accion local procesada)");
}

// Se invoca desde loop(), una vez finalizada la lectura de los datagramas.
void processDeferredAction() {
  DeferredAction action = deferredAction;
  if (action == ACTION_NONE) return;
  deferredAction = ACTION_NONE;
  if (action == ACTION_REBOOT) {
    Serial.printf("DOWNLINK: reinicio autorizado cmd_id=%lu. Reiniciando...\n",
                  (unsigned long)deferredCmdId);
    Serial.flush();
    delay(1000);  // ACK enviado ANTES del reinicio (entrega no garantizada por UDP).
    ESP.restart();
    return;
  }
  if (action == ACTION_GPS) {
    forceGPS = true;
    Serial.printf("DOWNLINK: iniciando GNSS cmd_id=%lu (LTE no disponible durante GNSS)\n",
                  (unsigned long)deferredCmdId);
    telemetryCmdId = (int32_t)deferredCmdId;
    bool ok = sendTelemetry("gps");
    telemetryCmdId = -1;
    if (!ok) Serial.println("DOWNLINK: fallo local al enviar resultado GPS");
  } else if (action == ACTION_STATUS) {
    Serial.printf("DOWNLINK: preparando estado cmd_id=%lu\n", (unsigned long)deferredCmdId);
    telemetryCmdId = (int32_t)deferredCmdId;
    bool ok = sendTelemetry("status");
    telemetryCmdId = -1;
    if (!ok) Serial.println("DOWNLINK: fallo local al enviar estado");
  } else if (action == ACTION_TELEMETRY) {
    Serial.printf("DOWNLINK: preparando telemetria cmd_id=%lu\n", (unsigned long)deferredCmdId);
    telemetryCmdId = (int32_t)deferredCmdId;
    bool ok = sendTelemetry("remote");
    telemetryCmdId = -1;
    if (!ok) Serial.println("DOWNLINK: fallo local al enviar telemetria");
  }
}

// AT+CARECV en firmware R1951.07: +CARECV: <bytes>,<datos>\r\nOK.
// La respuesta puede incluir URCs entre lineas; se extraen exactamente los bytes
// indicados por <bytes>, sin imprimir credenciales del JSON en el terminal.
// Retorno: >0 mensaje, 0 sin datos, -1 fallo de lectura.
int readDownlinkOnce(String &payload) {
  const String cmd = String("AT+CARECV=") + DOWNLINK_SOCKET + ",400";
  String response;
  if (!command(cmd, 7000, &response, true)) {
    ++rxReadErrors;
    Serial.println("DOWNLINK: CARECV sin OK; se reintentara");
    return -1;
  }
  int p = response.indexOf("+CARECV:");
  if (p < 0) {
    ++rxReadErrors;
    Serial.println("DOWNLINK: respuesta CARECV sin cabecera");
    return -1;
  }
  p += strlen("+CARECV:");
  while (p < (int)response.length() && response[p] == ' ') ++p;
  int comma = response.indexOf(',', p);
  int newline = response.indexOf('\n', p);
  if (comma < 0 || (newline >= 0 && newline < comma)) {
    // Versiones del firmware pueden responder +CARECV: 0 cuando no hay bytes.
    int n = response.substring(p, newline >= 0 ? newline : response.length()).toInt();
    if (n == 0) { ++rxEmptyCount; return 0; }
    ++rxReadErrors;
    Serial.println("DOWNLINK: CARECV formato no reconocido");
    return -1;
  }
  int n = response.substring(p, comma).toInt();
  if (n == 0) { ++rxEmptyCount; return 0; }
  if (n < 0 || n > 400 || comma + 1 + n > (int)response.length()) {
    ++rxReadErrors;
    Serial.println("DOWNLINK: longitud CARECV inconsistente");
    return -1;
  }
  payload = response.substring(comma + 1, comma + 1 + n);
  return n;
}

void pollDownlink() {
  if (manualAT || !downlinkReady) return;
  const uint32_t now = millis();
  const bool notified = (rxPendingId == DOWNLINK_SOCKET);
  const bool periodic = (now - lastDownlinkPoll >= DOWNLINK_POLL_MS);
  if (!notified && !periodic) return;
  rxPendingId = -1;
  lastDownlinkPoll = now;
  if (periodic) ++rxPollCount;
  if (notified || atDebug)
    Serial.printf("DOWNLINK RX: %s, consultando CARECV CID %u\n",
                  notified ? "aviso URC" : "sondeo periodico", DOWNLINK_SOCKET);
  // Vaciar varios mensajes pendientes sin bloquear el loop indefinidamente.
  for (uint8_t i = 0; i < DOWNLINK_MAX_DRAIN; ++i) {
    String payload;
    int n = readDownlinkOnce(payload);
    if (n <= 0) break;
    Serial.printf("DOWNLINK RX: %d bytes recibidos en CID %u\n", n, DOWNLINK_SOCKET);
    handleDownlink(payload); // ejecuta la orden y envia ACK si procede
    // El envio ACK puede generar mas URCs, que no se pierden.
  }
}

// Estado de red dinamico. Solo se consulta fuera de modo AT directo.
struct RadioStatus {
  String technology = "unknown";
  String operatorName = "unknown";
  String registration = "unknown";
  String rawCPSI = "";
  int csq = -1, rsrp = 999, rsrq = 999, rssi = 999, rssnr = 999;
  bool radioMetricsValid = false;
};
RadioStatus radio;

String atValue(const String &response, const char *prefix) {
  int p = response.indexOf(prefix);
  if (p < 0) return "";
  p += strlen(prefix);
  int end = response.indexOf('\n', p);
  String value = response.substring(p, end < 0 ? response.length() : end);
  value.trim();
  return value;
}

// CPSI LTE-M/NB-IoT: ultimos cuatro parametros = RSRQ,RSRP,RSSI,RSSNR.
// RSSNR es valor bruto de modem; no se etiqueta directamente como dB.
void readRadio() {
  String response;
  if (command("AT+CPSI?", 3500, &response, true)) {
    String cps = atValue(response, "+CPSI:");
    radio.rawCPSI = cps;
    radio.radioMetricsValid = false;
    radio.rsrq = radio.rsrp = radio.rssi = radio.rssnr = 999;
    if (cps.startsWith("LTE CAT-M1,")) radio.technology = "LTE-M";
    else if (cps.startsWith("LTE NB-IOT,")) radio.technology = "NB-IoT";
    else radio.technology = "unknown";
    if (radio.technology != "unknown") {
      int commaCount = 0;
      for (size_t i = 0; i < cps.length(); i++) if (cps[i] == ',') commaCount++;
      if (commaCount == 13) { // 14 campos: modo..RSSNR
        int start = 0;
        String f[14];
        for (int i = 0; i < 14; i++) {
          int e = cps.indexOf(',', start);
          f[i] = cps.substring(start, e < 0 ? cps.length() : e);
          f[i].trim(); start = e + 1;
        }
        radio.rsrq = f[10].toInt(); radio.rsrp = f[11].toInt();
        radio.rssi = f[12].toInt(); radio.rssnr = f[13].toInt();
        radio.radioMetricsValid = true;
      }
    }
  } else {
    radio.technology = "unknown";
    radio.radioMetricsValid = false;
  }
  if (command("AT+COPS?", 3500, &response, true)) {
    String cops = atValue(response, "+COPS:");
    int firstQuote = cops.indexOf('"');
    int secondQuote = firstQuote < 0 ? -1 : cops.indexOf('"', firstQuote + 1);
    radio.operatorName = (secondQuote > firstQuote) ?
                         cops.substring(firstQuote + 1, secondQuote) : "unknown";
  } else radio.operatorName = "unknown";
  if (command("AT+CEREG?", 3500, &response, true)) {
    String reg = atValue(response, "+CEREG:");
    int comma = reg.indexOf(',');
    if (comma >= 0) {
      int stat = reg.substring(comma + 1).toInt();
      radio.registration = stat == 5 ? "roaming" : stat == 1 ? "home" : "not_registered";
    } else radio.registration = "unknown";
  } else radio.registration = "unknown";
}

void printRadio() {
  Serial.printf("RED: tecnologia=%s operador=%s registro=%s CSQ=", radio.technology.c_str(),
                radio.operatorName.c_str(), radio.registration.c_str());
  if (radio.csq < 0) Serial.println("n/d");
  else Serial.println(radio.csq);
  if (radio.radioMetricsValid) {
    Serial.printf("RADIO: RSRP=%d dBm, RSRQ=%d dB, RSSI=%d dBm, RSSNR bruto=%d, SINR estimado=%d dB\n",
                  radio.rsrp, radio.rsrq, radio.rssi, radio.rssnr, 2 * radio.rssnr - 20);
  } else Serial.println("RADIO: metricas CPSI no disponibles");
  Serial.println("CPSI bruto: " + radio.rawCPSI);
}

void printCounters() {
  Serial.printf("UDP CONTADORES: intentos=%lu aceptados_localmente=%lu fallos_locales=%lu\n",
                (unsigned long)packetSeq, (unsigned long)udpAccepted, (unsigned long)udpFailed);
  Serial.printf("DOWNLINK: comandos=%lu rechazados=%lu ACK_locales=%lu escucha=%s\n",
                (unsigned long)downlinkAccepted, (unsigned long)downlinkRejected,
                (unsigned long)downlinkAcks, downlinkReady ? "si" : "no");
  Serial.printf("DOWNLINK RX: URC=%lu sondeos=%lu vacios=%lu fallos_lectura=%lu pendientes=%d\n",
                (unsigned long)rxURCCount, (unsigned long)rxPollCount,
                (unsigned long)rxEmptyCount, (unsigned long)rxReadErrors, rxPendingId);
  Serial.println("NOTA: aceptacion local UDP no confirma entrega en 1NCE OS");
}

// Tras CFUN=1, CEREG=1/5 puede adelantarse a la disponibilidad de CSQ/CPSI.
// Hasta cuatro lecturas espaciadas, sin alterar las metricas ni el modo AT directo.
void refreshRadioMetricsWithRetry() {
  for (uint8_t attempt = 1; attempt <= RADIO_METRICS_RETRIES; ++attempt) {
    readSignal();
    readRadio();
    if (radio.csq >= 0 && radio.technology != "unknown") {
      if (attempt > 1) {
        Serial.printf("RED: metricas recuperadas en intento %u\n", attempt);
      }
      return;
    }
    if (attempt < RADIO_METRICS_RETRIES) {
      Serial.printf("RED: CSQ o CPSI aun no disponibles (intento %u/%u); reintentando...\n",
                    attempt, RADIO_METRICS_RETRIES);
      delay(RADIO_METRICS_RETRY_MS);
    }
  }
  Serial.println("AVISO: CSQ/CPSI no disponibles tras reintentos; se enviaran null/unknown");
}

void readDHT() {
  lastHumidity = dht.readHumidity();
  lastTemp = dht.readTemperature();
}

void readSignal() {
  String r;
  radio.csq = -1;
  if (!command("AT+CSQ", 3500, &r, true)) return;
  int p = r.indexOf("+CSQ:");
  if (p < 0) return;
  int csq = r.substring(p + 5).toInt();
  if (csq >= 0 && csq <= 31) radio.csq = csq;
}

String makePayload(const char *reason, uint32_t seq, bool gpsFresh = false) {
  int battery = PMU.isBatteryConnect() ? PMU.getBatteryPercent() : -1;
  String s = "{\"id\":\"" + String(DEVICE_ID) + "\"";
  s += ",\"event\":\"" + String(reason) + "\"";
  s += ",\"seq\":" + String(seq);
  if (telemetryCmdId >= 0) s += ",\"cmd_id\":" + String(telemetryCmdId);
  s += ",\"uptime_ms\":" + String(millis());
  s += ",\"temp_c\":" + (isnan(lastTemp) ? String("null") : String(lastTemp, 1));
  s += ",\"humidity\":" + (isnan(lastHumidity) ? String("null") : String(lastHumidity, 1));
  s += ",\"battery_pct\":" + (battery < 0 ? String("null") : String(battery));
  s += ",\"led\":" + String(ledOn ? "true" : "false");
  s += ",\"lat\":" + (lastGPSFix ? String(lastLat, 6) : String("null"));
  s += ",\"lon\":" + (lastGPSFix ? String(lastLon, 6) : String("null"));
  s += ",\"gps_valid\":" + String(lastGPSFix ? "true" : "false");
  // gps_cached=false solo si este mensaje contiene un fix obtenido en esta peticion.
  s += ",\"gps_cached\":" + String(lastGPSFix && !gpsFresh ? "true" : "false");
  s += ",\"gps_age_s\":";
  s += lastGPSFix ? String((millis() - lastGPSFixMs) / 1000UL) : String("null");
  s += ",\"csq\":";
  s += String(radio.csq < 0 ? "null" : String(radio.csq));
  s += ",\"network\":\"" + radio.technology + "\"";
  s += "}";
  return s;
}

bool sendTelemetry(const char *reason) {
  readDHT();
  // GPS SOLO por comando g o tarea automatica independiente.
  const bool requestedGPS = forceGPS;
  bool gpsFresh = false;
  if (requestedGPS) gpsFresh = getGPS(); // ahora espera el registro LTE tras GNSS
  forceGPS = false;
  if (requestedGPS) refreshRadioMetricsWithRetry();
  else { readSignal(); readRadio(); } // camino normal sin esperas adicionales
  uint32_t seq = ++packetSeq;
  String json = makePayload(reason, seq, gpsFresh);
  Serial.println("JSON: " + json);
  bool sent = sendUDP(json);
  if (sent) udpAccepted++; else udpFailed++;
  beep();  // pitido por intento, nunca como confirmacion de 1NCE
  Serial.printf("UDP: seq=%lu %s\n", (unsigned long)seq,
                sent ? "aceptado por modem" : "fallo local/indeterminado");
  lastSendAttempt = millis();
  return sent;
}

void initModemAndPMU() {
  if (!PMU.begin(Wire, AXP2101_SLAVE_ADDRESS, I2C_SDA, I2C_SCL)) {
    Serial.println("ERROR: no se detecta AXP2101");
    while (true) delay(1000);
  }
  PMU.setChargingLedMode(XPOWERS_CHG_LED_ON);
  PMU.disableDC2(); PMU.disableDC4(); PMU.disableDC5();
  PMU.disableALDO1(); PMU.disableALDO2(); PMU.disableALDO3(); PMU.disableALDO4();
  PMU.disableBLDO2(); PMU.disableCPUSLDO(); PMU.disableDLDO1(); PMU.disableDLDO2();
  if (esp_sleep_get_wakeup_cause() == ESP_SLEEP_WAKEUP_UNDEFINED) {
    PMU.disableDC3(); delay(200);
  }
  PMU.setBLDO1Voltage(3300); PMU.enableBLDO1(); // NO apagar: conversor de nivel del modem
  PMU.setDC3Voltage(3000); PMU.enableDC3();
  PMU.setBLDO2Voltage(3300); PMU.enableBLDO2(); // antena GNSS
  SerialAT.begin(115200, SERIAL_8N1, BOARD_MODEM_RXD_PIN, BOARD_MODEM_TXD_PIN);
  pinMode(BOARD_MODEM_PWR_PIN, OUTPUT);
  for (uint8_t tries = 0; tries < 30; tries++) {
    if (command("AT", 1200)) { Serial.println("MODEM: OK"); return; }
    if (tries % 10 == 9) {
      digitalWrite(BOARD_MODEM_PWR_PIN, LOW); delay(100);
      digitalWrite(BOARD_MODEM_PWR_PIN, HIGH); delay(1000);
      digitalWrite(BOARD_MODEM_PWR_PIN, LOW);
    }
  }
  Serial.println("AVISO: modem sin respuesta, usar modo AT para diagnostico");
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  pinMode(PIN_LED, OUTPUT); digitalWrite(PIN_LED, LOW);
  pinMode(PIN_BUTTON, INPUT_PULLUP);
  ledcAttach(PIN_BUZZER, 1800, 8); // Arduino-ESP32 core 3.x
  ledcWriteTone(PIN_BUZZER, 0);
  dht.begin();
  initModemAndPMU();
  Serial.println("'!' AT manual/automatico | 's' enviar | 'l' LED | 'g' GPS+envio | 'p' vista previa | 'n' red | 'c' contadores | 'd' trazas AT | 'r' receptor");
  Serial.println("GPS por defecto solo manual con 'g'; UDP periodico cada hora");
  Serial.println("v0.6.2: recuperacion servidor UDP tras GNSS; sondeo respaldo 60 s");
  // No lanzamos envio antes de poder comprobar el terminal y el GPS.
  lastSendAttempt = millis();
}

void loop() {
  while (Serial.available()) {
    char ch = (char)Serial.read();
    if (ch == '!') {
      manualAT = !manualAT;
      Serial.println(manualAT ? "MODO AT DIRECTO: automatico pausado" : "MODO AUTOMATICO");
      flushAT();
      if (!manualAT) { downlinkReady = false; lastDownlinkAttempt = 0; rxPendingId = DOWNLINK_SOCKET; lastDownlinkPoll = 0; }
    } else if (manualAT) {
      SerialAT.write(ch); // transparente, como ATDebug original
    } else if (ch == 'd') {
      atDebug = !atDebug;
      Serial.println(atDebug ? "TRAZA AT: ON" : "TRAZA AT: OFF");
    } else if (ch == 's') {
      pendingSend = true; pendingReason = "manual"; pendingRetry = false;
    } else if (ch == 'l') {
      ledOn = !ledOn; digitalWrite(PIN_LED, ledOn); pendingSend = true; pendingReason = "led"; pendingRetry = false;
    } else if (ch == 'g') {
      forceGPS = true; pendingSend = true; pendingReason = "gps"; pendingRetry = false;
    } else if (ch == 'p') {
      readDHT(); readSignal(); readRadio();
      printRadio();
      Serial.println(makePayload("preview", packetSeq));
    } else if (ch == 'n') {
      readSignal(); readRadio(); printRadio();
    } else if (ch == 'c') {
      printCounters();
    } else if (ch == 'r') {
      downlinkReady = false; lastDownlinkAttempt = 0;
      ensureDownlink(true);
    }
  }
  if (manualAT) {
    while (SerialAT.available()) Serial.write(SerialAT.read());
    delay(1);
    return;
  }
  collectIdleURCs();
  // Primero comprobar/reabrir el receptor: pollDownlink no puede leer si no escucha.
  ensureDownlink();
  pollDownlink();
  processDeferredAction();
  bool raw = digitalRead(PIN_BUTTON);
  if (raw != lastButtonRaw) lastButtonEdge = millis();
  if (millis() - lastButtonEdge >= DEBOUNCE_MS && raw != buttonStable) {
    buttonStable = raw;
    if (buttonStable == LOW) {
      ledOn = !ledOn; digitalWrite(PIN_LED, ledOn ? HIGH : LOW);
      pendingSend = true; pendingReason = "button"; pendingRetry = false;
      Serial.printf("PULSADOR: LED %s y envio solicitado\n", ledOn ? "encendido" : "apagado");
    }
  }
  lastButtonRaw = raw;
  if (GPS_AUTOMATICO && !pendingSend && !pendingRetry &&
      millis() - lastGPSAttempt >= GPS_INTERVAL_MS) {
    Serial.println("GNSS: actualizacion automatica independiente");
    getGPS();  // espera recuperacion LTE; no transmite por si sola
  }
  if (!pendingSend && millis() - lastSendAttempt >= EVERY_MS) {
    pendingSend = true; pendingReason = "hourly"; pendingRetry = false;
  }
  if (pendingSend && (!pendingRetry || millis() - lastSendAttempt >= RETRY_MS)) {
    pendingSend = false;
    bool sent = sendTelemetry(pendingReason);
    if (!sent) {
      pendingSend = true; pendingRetry = true;
      Serial.println("Reintento UDP dentro de 60 s (mientras no llegue una nueva orden)");
    } else {
      pendingRetry = false;
    }
  }
  delay(5);
}
