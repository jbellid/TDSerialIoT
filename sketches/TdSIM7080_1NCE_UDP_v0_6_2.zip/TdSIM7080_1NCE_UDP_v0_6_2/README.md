TdSIM7080_1NCE_UDP v0.6.2

Firmware sobre LilyGO T-SIM7080G-S3, firmware SIM7080G R1951.07.


Novedades

- **Pulsador** (GPIO14 ↔ GND): al pulsar, **alterna** el estado del LED (GPIO10) y solicita un envío `event:"button"`. Antirrebote 45 ms; solo actúa en la transición a pulsado.
- **Sondeo de respaldo** `AT+CARECV=1,400` cada **60 segundos**, en vez de 5 s. Los avisos `+CADATAIND`, `+CANEW` y `buffer full` siguen provocando lectura inmediata. El sondeo es una salvaguarda ante URC perdidas, **no un requisito de UDP**. Puede variarse `DOWNLINK_POLL_MS` o desactivarse modificando la lógica del código, pero no se ha desactivado en esta versión.
- Comandos remotos adicionales `led_toggle`, `buzzer`, `gps`, `status`, `reboot`. Se conservan `led_on`, `led_off`, `telemetry`.
- Los comandos que implican operaciones de red prolongadas generan primero un ACK con `status:"accepted"` y después envían un JSON con el resultado (campo `cmd_id`). Los comandos inmediatos generan ACK `status:"executed"`.
- Se conservan los modos de terminal y la configuración del módem, DHT11, GNSS y batería. **No hay cambios para ahorro energético**.

Órdenes para Device Controller (UDP, puerto 3000)

Agregar siempre `"token":"TU_TOKEN_REAL"` y un `id` entero **nuevo** (los ocho últimos se guardan en RAM para evitar duplicados).

```json
{"cmd":"led_on","id":201,"token":"TU_TOKEN_REAL"}
{"cmd":"led_off","id":202,"token":"TU_TOKEN_REAL"}
{"cmd":"led_toggle","id":203,"token":"TU_TOKEN_REAL"}
{"cmd":"buzzer","id":204,"duration_ms":350,"token":"TU_TOKEN_REAL"}
{"cmd":"telemetry","id":205,"token":"TU_TOKEN_REAL"}
{"cmd":"status","id":206,"token":"TU_TOKEN_REAL"}
{"cmd":"gps","id":207,"token":"TU_TOKEN_REAL"}
{"cmd":"reboot","id":208,"confirm":"REBOOT","token":"TU_TOKEN_REAL"}
```

`buzzer`: duración permitida de **50 a 2000 ms**, tono 1800 Hz; usar buzzer piezo pasivo apto para 3,3 V. `reboot` requiere `confirm: "REBOOT"`; solo usar en laboratorio. Token simple sin autenticación criptográfica ni protección persistente contra repetición: **no es un mecanismo seguro para actuadores críticos**.

Respuestas y semántica

- `led_on`, `led_off`, `led_toggle`, `buzzer`: ACK `event:"command_ack"`, `status:"executed"` tras ejecutar.
- `telemetry`, `status`, `gps`: ACK `status:"accepted"`; después otro paquete con `event:"remote"`, `"status"` o `"gps"` y `cmd_id` para correlación. No equivale a un OK de ejecución: confirmar el mensaje de resultado en Historian.
- `gps`: detiene temporalmente LTE, obtiene (o intenta) posición, recupera LTE y vuelve a abrir el receptor en el siguiente ciclo. La posición se distingue por `gps_valid`, `gps_cached` y `gps_age_s`.
- `reboot`: ACK `status:"accepted"`, y después `ESP.restart()`. El ACK puede no llegar; el reinicio no incluye ACK posterior. Si se desea confirmar el reinicio, añadir un evento `boot` en versiones posteriores.
- `AT+CASEND ... OK` indica **aceptación por el módem**, no entrega garantizada; verificar Historian.
- Si llega una segunda orden larga mientras otra está pendiente, se rechaza para evitar sobrescribirla.

Comandos serie

`!` conmuta puente AT / automático, `d` trazas, `s` enviar, `l` alternar LED y enviar, `g` GPS y enviar, `p` vista previa, `n` radio, `c` contadores, `r` receptor.

Limitaciones

Compilación y ejecución **no verificadas en hardware** aquí. La recepción es dependiente de URC, con sondeo de respaldo cada 60 s. Si una URC se pierde, la reacción puede demorarse hasta 60 s. Durante GNSS no se pueden recibir órdenes LTE. La operación de GPS sigue bloqueando el bucle durante su adquisición/recuperación (hasta los límites configurados); el sondeo no trabaja en ese intervalo. Los comandos remotos autorizan acciones mediante token en texto claro en un datagrama UDP; no usar para funciones de seguridad física ni desplegar en entornos no controlados.


CAMBIOS TRAS v0.5

- Lectura automática de mensajes entrantes (`AT+CARECV=1,400`) ante `+CADATAIND`, `+CANEW` o aviso de búfer lleno.
- **Sondeo de respaldo cada cinco segundos**, aunque no llegue la notificación URC. Esto permite recuperar mensajes acumulados y verificar funcionamiento en firmware `1951B17SIM7080`.
- Vaciado limitado a cuatro lecturas consecutivas por ciclo, para no bloquear las demás funciones.
- Traza de recepción, contadores RX y ocultación del token en las trazas AT automáticas.
- Recuperación del sondeo tras alternar entre modo AT directo y automático.
- Conserva GPS, batería, DHT11, LED, buzzer, pulsador y los envíos periódicos a `udp.os.1nce.com:4445`.

Antes de compilar

1. Copiar **`utilities.h` original de LilyGO de la revisión exacta de la placa** a la carpeta del `.ino`.
2. Usar el soporte de placa ESP32-S3 con Arduino-ESP32 3.x y disponer de **XPowersLib, DHT (Adafruit), ArduinoJson 7.x** y sus dependencias.
3. Modificar `DOWNLINK_TOKEN` por una clave larga aleatoria de al menos 16 caracteres, **igual a la usada en Device Controller**. El firmware rechaza comandos con el valor de ejemplo.
4. Revisar `DEVICE_ID` si ya utilizas un identificador propio. No incluir claves reales en repositorios públicos ni logs compartidos.


CAMBIOS TRAS v0.4.0
- Al ejecutar g, se adquiere GNSS, se restaura LTE con AT+CFUN=1 y se espera CEREG=1/5
  (hasta 120 s) ANTES de consultar CSQ y CPSI y construir el JSON.
- Si CSQ o CPSI no estan disponibles, se repiten ambas lecturas hasta 4 veces,
  con pausas de 2 s, sin inventar datos si continuan sin estar disponibles.
- getGPS registra el tiempo hasta el fix y el tiempo hasta recuperar registro.
- Se agregan gps_valid, gps_cached y gps_age_s.
    gps_valid = existe posicion valida adquirida desde el arranque
    gps_cached = posicion anterior reutilizada (false en un g con fix nuevo)
    gps_age_s = antiguedad desde el ultimo fix; null si no existe
- En modo p y en los envios horarios, una posicion ya adquirida se considera cache.


CAMBIOS DESDE v0.3
- Mantiene el transporte UDP probado hacia udp.os.1nce.com:4445.
- Tecnologia de red determinada mediante AT+CPSI? (LTE-M / NB-IoT / unknown).
- Diagnostico local n: CSQ, operador, registro, RSRP, RSRQ, RSSI, RSSNR bruto y SINR estimado.
- Previsualizacion p ahora refresca DHT11 y estado de radio sin enviar datos.
- Consulta AT+CASTATE? y solo cierra el socket 0 antes de abrir si consta activo.
- Reutiliza contexto de aplicacion si AT+CNACT? indica +CNACT: 0,1 (ya incluido en v0.3).
- Estadisticas con c: intentos, aceptados localmente, fallos locales.
- No modifica GNSS ni comportamiento del boton, LED y buzzer.
- Sin optimizaciones de consumo energetico.

VERSION v0.3
- Basada en v0.2 cuya recepcion UDP en 1NCE OS fue confirmada.
- Mantiene la secuencia de APN, contexto, CAOPEN, CASEND y CACLOSE probada.
- Ignora silenciosamente ERROR de CACLOSE previo si no existe socket.
- GNSS ya NO se ejecuta en cada envio (ideal para interiores).
- Envios periodicos 60 minutos y pulsador inmediato sin GPS.
- g obtiene GPS (hasta 90 s), restaura LTE y envia.
- Configuracion GPS_AUTOMATICO=false por defecto; periodo independiente de 6 h configurable.
- JSON incluye seq (contador desde reinicio), uptime_ms (tiempo desde reinicio), csq y network.
- Traza AT con d: TX/RX de comandos y respuestas. No registra contenido del JSON en AT TX,
  pero el JSON se muestra por separado. Las trazas pueden contener metadatos del modem.
- El firmware del SIM7080 puede responder a CASEND solo con OK; NO se exige +CASEND
  posterior, porque su formato y momento varian segun revision.
- No hay acuse de recibo UDP de extremo a extremo; confirmar en 1NCE OS.


COMANDOS TERMINAL (115200)
! alternar modo AT directo / automatico
s envio manual
l alternar LED y enviar
g adquirir GPS y enviar (puede tardar hasta 90 s + reconexion)
p actualizar sensores y red, mostrar JSON sin enviarlo
n diagnostico de red y señal, sin enviar
c contadores de intentos UDP
d activar/desactivar traza de comandos AT


INSTALACION
1. Copie a esta carpeta el fichero utilities.h del MISMO ejemplo ATDebug de LilyGO que ya le funcionaba.
2. Seleccione placa ESP32S3 Dev Module (core ESP32 3.x, USB CDC On Boot Enabled), en Arduino instala el soporte para ESP32-S3

	Si no lo has hecho antes, el entorno necesita reconocer los chips de Espressif:
		1. Ve a Archivo > Preferencias.
		2. En el cuadro Gestor de URLs Adicionales de Tarjetas, añade la dirección oficial:
		https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
		3. Ve a Herramientas > Placa > Gestor de tarjetas, busca esp32 e instala la última versión estable desarrollada por Espressif Systems.
	Paso 2: Copiar las librerías obligatorias de LilyGO
		El sketch utiliza librerías específicas modificadas por el fabricante para gestionar el módem y el chip de energía (PMU AXP2101).
		1. Descarga el repositorio completo desde el GitHub de LilyGo-T-SIM7080G.
		2. Abre la carpeta descargada, entra en el directorio llamado lib/ y copia todas las carpetas que contiene.
		3. Pégalas en el directorio de librerías de tu ordenador (usualmente ubicado en Documentos/Arduino/libraries).
	Paso 3: Configurar las opciones de la placa en Arduino IDE
		Conecta tu tarjeta mediante un cable USB-C de datos al ordenador. En la pestaña Herramientas, cambia exactamente los siguientes parámetros para que coincidan con el hardware del T-SIM7080-S3:
			Ajuste / Parámetro	Valor a seleccionar
			Placa (Board)	ESP32S3 Dev Module
			USB CDC On Boot	Enabled (Crucial para ver el monitor serie)
			Flash Size	16MB (128Mb)
			Partition Scheme	16M Flash (3MB APP/9.9MB FATFS)
			PSRAM	OPI PSRAM
			Puerto (Port)	Elige el puerto COM asignado a tu placa
3. Instale DHT sensor library y XPowersLib compatibles con el repositorio LilyGO.
4. No conecte camara ni microSD; GPIO 9/10/14/21 estan compartidos con estos perifericos.
5. Configure el monitor serie a 115200 y finales CR+LF para modo AT.
6. Pulse 's' para enviar; '!' activa/desactiva el puente AT manual.
7. El SIM7080G NO puede adquirir GNSS y comunicar LTE simultaneamente: cada envio detiene la radio para GNSS y despues la restaura. Si no hay fix en 90 s, lat/lon nulas o ultimo fix cacheado.
8. El retorno OK de CASEND no confirma recepcion de 1NCE; comprobar Historian/Device Inspector.
9. El destino UDP es udp.os.1nce.com:4445, payload JSON <= 508 bytes.

VARIABLES MODIFICABLES
DEVICE_ID, EVERY_MS, RETRY_MS, GPS_AUTOMATICO, GPS_INTERVAL_MS, GNSS_MAX_MS.

NOTAS
- network se envia dinamicamente: LTE-M o NB-IoT. Si falla consulta CPSI, unknown.
- CSQ=99 se comunica como null, otras 0..31 se transmiten numericamente.
- Las metricas detalladas solo se muestran en terminal, no en el JSON compacto.
- SINR estimado = 2*RSSNR - 20 (segun manual SIMCom), no medicion directa.
- seq y contadores se reinician en cada arranque. No se conserva historico en memoria flash.
- CASEND OK significa aceptacion por modem, NO acuse de recibo de 1NCE OS.
- Los envios periodicos son cada 60 minutos, reintento local en 60 segundos.
- GPS automatico desactivado por defecto; g fuerza una lectura.
- Los sensores no conectados reportan null; la bateria conectada puede reportar 100%.
- seq se reinicia tras un reset, no sirve de ID global unico.
- uptime_ms no es hora UTC ni fecha.
- GPS sin posicion en interior es esperable; la anterior se conserva en RAM.
- Lecturas DHT11 null si no esta conectado.
- La comunicacion ya ha funcionado con 1NCE, pero esta revision requiere prueba real.
